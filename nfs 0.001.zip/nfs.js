var road = document.getElementById('road');
var y = 0;
var speed = 5;
var count = 0;
var count_1 = 0;

function createCar(){
var car = document.createElement('div')
car.id = 'car';
road.appendChild(car);
}
function move(){
y+=speed;
road.style.backgroundPosition = '0px ' + y + 'px';
}
function  action(){
if(event.keyCode == 38){
  speed++;
  }
  if(event.keyCode == 40){
    speed--;
  }
  if(event.keyCode == 70 && count < 70){
          count += event.keyCode;
          alert(count);
        addLight();
  }
if (event.keyCode == 70) {
  count_1 += event.keyCode;
}
if(event.keyCode == 70 && count_1 > 70){
  removeLight();
  count_1 = 0;
  }
}
setInterval(move , 10);
createCar();

function addLight(){
     var parenTAL = document.getElementById('road');
  var light = document.createElement('div');
  var light_1 = document.createElement('div');
  light.className = 'gradient';
   light_1.className = 'gradient';
   parenTAL.appendChild(light);
   parenTAL.appendChild(light_1);

}
function removeLight(){
  var delets = document.querySelector('#road');
  delets.removeChild(delets.children[1,2]);
  delets.removeChild(delets.children[1]);
}



// найти клавишу  L добавить 2 дива с классом lights и включаются фары при вторичном нажатии выключаем
